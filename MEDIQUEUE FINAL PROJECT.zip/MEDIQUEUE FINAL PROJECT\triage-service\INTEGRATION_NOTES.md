# PHP integration notes

- `api_original.php` is the unmodified `api.php` from the supplied project.
- `api.php` contains the symptom-classifier integration.
- The functional changes are limited to the `/triage` classification path and input-rejection handling.
- Existing database logic, queue logic, Server-Sent Events, and wait-time service integration remain unchanged.
- The helper calls `http://localhost:5002/predict_urgency`.
- If the classifier service is unavailable, the existing keyword rules remain available as a fallback.
- If the classifier explicitly rejects nonsensical or unrelated text, the API returns a validation error instead of saving a false urgency value.
