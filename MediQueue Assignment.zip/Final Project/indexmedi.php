<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MediQueue SA - Main Form</title>
    <link rel="stylesheet" href="style.css">

    <style>
        .main-container {
            max-width: 1000px;
            margin: 50px auto;
            padding: 20px;
        }

        .welcome-card {
            text-align: center;
            padding: 35px;
            margin-bottom: 30px;
        }

        .welcome-card h2 {
            margin-bottom: 10px;
            font-size: 32px;
        }

        .welcome-card p {
            margin: 0;
            font-size: 17px;
        }

        .role-container {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 25px;
        }

        .role-card {
            padding: 35px;
            text-align: center;
            border-radius: 12px;
        }

        .role-icon {
            font-size: 55px;
            margin-bottom: 15px;
        }

        .role-card h3 {
            font-size: 25px;
            margin: 10px 0;
        }

        .role-card p {
            min-height: 48px;
            margin-bottom: 25px;
        }

        .role-button {
            width: 100%;
            padding: 14px 20px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
        }

        .system-info {
            margin-top: 30px;
            text-align: center;
            padding: 18px;
        }

        @media (max-width: 700px) {
            .role-container {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>

<body>

<header>
    <div>
        <h1>MediQueue SA</h1>
        <p>Virtual Healthcare Queue</p>
    </div>

    <div id="liveStatus">
        ● LIVE
    </div>
</header>

<main class="main-container">

    <section class="card welcome-card">
        <h2>Welcome to MediQueue SA</h2>
        <p>
            Please select how you would like to access the system.
        </p>
    </section>

    <section class="role-container">

        <div class="card role-card">
            <div class="role-icon">👤</div>
            <h3>Patient</h3>
            <p>
                Submit your symptoms, join the virtual queue,
                and monitor your position while waiting.
            </p>

            <button class="role-button"
                    onclick="window.location.href='patient.php'">
                Enter Patient Form
            </button>
        </div>

        <div class="card role-card">
            <div class="role-icon">👨‍⚕️</div>
            <h3>Doctor</h3>
            <p>
                View waiting patients, call the next patient,
                manage consultations, and complete referrals.
            </p>

            <button class="role-button"
                    onclick="window.location.href='doctor.php'">
                Enter Doctor Form
            </button>
        </div>

    </section>

    <section class="card system-info">
        <strong>● Live Queue System</strong>
        <p>
            Patient queue information updates automatically.
            No manual page refresh is required.
        </p>
    </section>

</main>

</body>
</html>
