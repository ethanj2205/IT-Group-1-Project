CREATE DATABASE IF NOT EXISTS mediqueue_sa;
USE mediqueue_sa;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(255) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('patient','doctor','admin') NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS hospitals (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS patients (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL UNIQUE,
  full_name VARCHAR(150) NOT NULL,
  date_of_birth DATE NULL,
  contact_number VARCHAR(30) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_patient_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS doctors (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL UNIQUE,
  hospital_id INT NOT NULL,
  full_name VARCHAR(150) NOT NULL,
  available BOOLEAN NOT NULL DEFAULT TRUE,
  average_consultation_minutes DECIMAL(6,2) NOT NULL DEFAULT 15,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_doctor_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_doctor_hospital FOREIGN KEY (hospital_id) REFERENCES hospitals(id)
);

CREATE TABLE IF NOT EXISTS triage_records (
  id INT AUTO_INCREMENT PRIMARY KEY,
  patient_id INT NOT NULL,
  symptoms TEXT NOT NULL,
  urgency ENUM('Low','Moderate','High') NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_triage_patient FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
  INDEX idx_triage_patient_created (patient_id, created_at)
);

CREATE TABLE IF NOT EXISTS queue_entries (
  id INT AUTO_INCREMENT PRIMARY KEY,
  queue_number VARCHAR(30) NOT NULL UNIQUE,
  hospital_id INT NOT NULL,
  patient_id INT NOT NULL,
  triage_id INT NOT NULL,
  doctor_id INT NULL,
  urgency ENUM('Low','Moderate','High') NOT NULL,
  status ENUM('Waiting','In Consultation','Completed','Referral','Cancelled') NOT NULL DEFAULT 'Waiting',
  joined_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  started_at TIMESTAMP NULL,
  completed_at TIMESTAMP NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_queue_hospital FOREIGN KEY (hospital_id) REFERENCES hospitals(id),
  CONSTRAINT fk_queue_patient FOREIGN KEY (patient_id) REFERENCES patients(id),
  CONSTRAINT fk_queue_triage FOREIGN KEY (triage_id) REFERENCES triage_records(id),
  CONSTRAINT fk_queue_doctor FOREIGN KEY (doctor_id) REFERENCES doctors(id),
  INDEX idx_queue_waiting (hospital_id, status, urgency, joined_at),
  INDEX idx_queue_patient (patient_id, status)
);

CREATE TABLE IF NOT EXISTS consultations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  queue_entry_id INT NOT NULL UNIQUE,
  patient_id INT NOT NULL,
  doctor_id INT NOT NULL,
  notes TEXT NOT NULL,
  outcome ENUM('In Progress','Completed','Referral') NOT NULL DEFAULT 'In Progress',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_consult_queue FOREIGN KEY (queue_entry_id) REFERENCES queue_entries(id),
  CONSTRAINT fk_consult_patient FOREIGN KEY (patient_id) REFERENCES patients(id),
  CONSTRAINT fk_consult_doctor FOREIGN KEY (doctor_id) REFERENCES doctors(id)
);

CREATE TABLE IF NOT EXISTS audit_log (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  action VARCHAR(100) NOT NULL,
  entity_type VARCHAR(50) NULL,
  entity_id INT NULL,
  metadata JSON NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_audit_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_audit_created (created_at)
);

/*
 * Migration for an existing MediQueue database.
 * CREATE TABLE IF NOT EXISTS does not change an existing column definition,
 * so this statement fixes databases created with the old two-value ENUM.
 */
ALTER TABLE consultations
  MODIFY outcome ENUM('In Progress','Completed','Referral') NOT NULL DEFAULT 'In Progress';


/*
 * Demo data
 *
 * The web page uses Patient ID 1 and Hospital ID 1 by default.  The original
 * project created the tables but did not create the records those controls
 * point to, which caused the foreign-key error when triage was submitted.
 * These INSERTs are safe to run more than once.
 */
INSERT INTO hospitals (id, name)
VALUES (1, 'MediQueue SA General Hospital')
ON DUPLICATE KEY UPDATE name = VALUES(name);

INSERT INTO users (id, email, password_hash, role)
VALUES
  (1, 'patient1@mediqueue.local', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC7u8X7w8Q2vQ1V0b3mW', 'patient'),
  (2, 'doctor1@mediqueue.local', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC7u8X7w8Q2vQ1V0b3mW', 'doctor')
ON DUPLICATE KEY UPDATE
  email = VALUES(email),
  password_hash = VALUES(password_hash),
  role = VALUES(role);

INSERT INTO patients (id, user_id, full_name, date_of_birth, contact_number)
VALUES
  (1, 1, 'Patient 1', NULL, '0000000000')
ON DUPLICATE KEY UPDATE
  user_id = VALUES(user_id),
  full_name = VALUES(full_name),
  contact_number = VALUES(contact_number);

INSERT INTO doctors (id, user_id, hospital_id, full_name, available, average_consultation_minutes)
VALUES
  (1, 2, 1, 'Doctor 1', TRUE, 15)
ON DUPLICATE KEY UPDATE
  user_id = VALUES(user_id),
  hospital_id = VALUES(hospital_id),
  full_name = VALUES(full_name),
  available = VALUES(available),
  average_consultation_minutes = VALUES(average_consultation_minutes);
