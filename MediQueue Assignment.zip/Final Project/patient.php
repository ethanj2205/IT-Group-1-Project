<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>MediQueue SA - Patient</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<header>
    <div>
        <h1>MediQueue SA</h1>
        <p>Virtual Healthcare Queue</p>
    </div>
    <div id="liveStatus">● LIVE</div>
</header>
<main>
<section class="card">
<h2 id="patientNumber">Patient 1</h2>
<label>Patient ID</label>
<input id="patientId" type="number" readonly>
<label>Hospital ID</label>
<input id="hospitalId" type="number" value="1">
<label>Symptoms</label>
<textarea id="symptoms" placeholder="Describe your symptoms..."></textarea>
<button onclick="submitTriage()">Submit Symptoms</button>
<div id="triageResult"></div>
<button id="joinButton" onclick="joinQueue()" disabled>Join Virtual Queue</button>
<div id="patientStatus"></div>
</section>
<section class="card full">
<div class="queueHeader">
<div><h2>Live Virtual Queue</h2><p>Automatically updated every 2 seconds</p></div>
<button onclick="loadQueue()">Refresh</button>
</div>
<div id="queue">Loading queue...</div>
</section>
</main>
<script>




let currentTriageId = null;

let currentConsultationQueueId = null;


/*
|--------------------------------------------------------------------------
| API helper
|--------------------------------------------------------------------------
*/

async function api(route, method = "GET", data = null)
{
    const url = "api.php?route=" + route;

    const options = {
        method,
        headers: {
            "Accept": "application/json"
        }
    };

    if (data !== null) {
        options.headers["Content-Type"] = "application/json";
        options.body = JSON.stringify(data);
    }

    const response = await fetch(url, options);
    const raw = await response.text();

    let result;

    try {
        result = raw ? JSON.parse(raw) : {};
    } catch (parseError) {
        console.error("API returned non-JSON data:", raw);
        throw new Error(
            "The server returned an invalid response. Check PHP/MySQL for an error."
        );
    }

    if (!response.ok) {
        throw new Error(
            result.error || "Request failed (HTTP " + response.status + ")"
        );
    }

    return result;
}

/*
|--------------------------------------------------------------------------
| Submit triage
|--------------------------------------------------------------------------
*/

async function submitTriage()
{

    const patientId =
        document
        .getElementById(
            "patientId"
        )
        .value;


    const symptoms =
        document
        .getElementById(
            "symptoms"
        )
        .value;


    if (!patientId) {

        alert(
            "Enter a Patient ID."
        );

        return;
    }


    if (!symptoms.trim()) {

        alert(
            "Enter at least one symptom."
        );

        return;
    }


    try {

        const result =
            await api(
                "triage",
                "POST",
                {
                    patient_id:
                        patientId,

                    symptoms:
                        symptoms
                }
            );


        currentTriageId =
            result.triage_id;


        document
        .getElementById(
            "triageResult"
        )
        .innerHTML = `

            <div class="result">

                <strong>
                    Triage Complete
                </strong>

                <span>
                    ${result.urgency}
                </span>

                <small>
                    Triage ID:
                    ${result.triage_id}
                </small>

            </div>

        `;


        document
        .getElementById(
            "joinButton"
        )
        .disabled = false;

    }

    catch (error) {

        alert(
            error.message
        );
    }
}


/*
|--------------------------------------------------------------------------
| Join queue
|--------------------------------------------------------------------------
*/

async function joinQueue()
{

    const patientId =
        document
        .getElementById(
            "patientId"
        )
        .value;


    const hospitalId =
        document
        .getElementById(
            "hospitalId"
        )
        .value;


    if (!currentTriageId) {

        alert(
            "Submit triage first."
        );

        return;
    }


    try {

        const result =
            await api(
                "queue_join",
                "POST",
                {
                    patient_id:
                        patientId,

                    triage_id:
                        currentTriageId,

                    hospital_id:
                        hospitalId
                }
            );


        document
        .getElementById(
            "patientStatus"
        )
        .innerHTML = `

            <div class="success">

                Successfully joined queue.

                <br>

                Queue Number:

                <strong>
                    ${result.queue_number}
                </strong>

            </div>

        `;


        loadQueue();

        if (window.advanceToNextPatient) {
            window.advanceToNextPatient();
        }

    }

    catch (error) {

        alert(
            error.message
        );
    }
}


/*
|--------------------------------------------------------------------------
| Load queue
|--------------------------------------------------------------------------
*/

async function loadQueue()
{
    const hospitalId = document
        .getElementById("hospitalId")
        .value
        .trim();

    if (!hospitalId) {
        return;
    }

    try {
        const result = await api(
            "queue&hospital_id=" + encodeURIComponent(hospitalId)
        );

        displayQueue(result.queue || []);
    }
    catch (error) {
        document.getElementById("queue").innerHTML =
            `<div class="error">${escapeHtml(error.message)}</div>`;
    }
}

function escapeHtml(value)
{
    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

/*
|--------------------------------------------------------------------------
| Display queue
|--------------------------------------------------------------------------
*/

function displayQueue(queue)
{

    const container =
        document
        .getElementById(
            "queue"
        );


    if (!queue.length) {

        container.innerHTML =
            `<div class="empty">
                No patients in queue.
            </div>`;

        return;
    }


    container.innerHTML =
        queue.map(
            patient => {

                const urgency =
                    patient.effective_urgency
                    .toLowerCase();


                return `

                <div class="queueItem">

                    <div class="queueNumber">

                        #${escapeHtml(patient.queue_number)}

                    </div>


                    <div class="patientInfo">

                        <strong>
                            ${escapeHtml(patient.full_name)}
                        </strong>

                        <span>
                            Position:
                            ${escapeHtml(patient.position ?? "-")}
                        </span>

                        <span>
                            Waiting:
                            ${escapeHtml(patient.waiting_minutes)}
                            min
                        </span>

                    </div>


                    <div>

                        <span class="
                            urgency
                            ${urgency}
                        ">

                            ${
                                patient.effective_urgency
                            }

                        </span>

                    </div>


                    <div>

                        <span>
                            Priority:
                        </span>

                        <strong>

                            ${
                                patient.priority_score
                            }

                        </strong>

                    </div>


                    <div>

                        <span class="
                            status
                        ">

                            ${escapeHtml(patient.status)}

                        </span>

                    </div>

                </div>

                `;
            }
        )
        .join("");
}




/* Patient queue auto-refresh */
(function () {
    const key = "mediqueue_next_patient_id";

    function getNextId() {
        let id = parseInt(localStorage.getItem(key) || "1", 10);
        if (!Number.isFinite(id) || id < 1) id = 1;
        return id;
    }

    function setPatientId(id) {
        const field = document.getElementById("patientId");
        if (field) {
            field.value = id;
            field.readOnly = true;
        }
        const label = document.getElementById("patientNumber");
        if (label) label.textContent = "Patient " + id;
    }

    function advanceToNextPatient() {
        const current = getNextId();
        localStorage.setItem(key, String(current + 1));
        setPatientId(current + 1);
        document.getElementById("symptoms").value = "";
        document.getElementById("triageResult").innerHTML = "";
        document.getElementById("patientStatus").innerHTML = "";
        document.getElementById("joinButton").disabled = true;
        currentTriageId = null;
    }

    window.addEventListener("DOMContentLoaded", function () {
        setPatientId(getNextId());
        loadQueue();
        setInterval(loadQueue, 2000);
    });

    window.advanceToNextPatient = advanceToNextPatient;
})();

</script>
</body>
</html>
