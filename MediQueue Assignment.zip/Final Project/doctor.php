<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>MediQueue SA - Doctor</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<header>

    <div>

        <h1>MediQueue SA</h1>

        <p>
            Virtual Healthcare Queue
        </p>

    </div>


    <div id="liveStatus">

        ● LIVE

    </div>

</header>


<main>



<main>
<!-- =====================================================
     DOCTOR
====================================================== -->

<section class="card">

<h2>Doctor Dashboard</h2>


<label>
Doctor ID
</label>

<input
    id="doctorId"
    type="number"
    value="1"
    placeholder="Example: 1"
>


<label>
Hospital ID
</label>

<input
    id="doctorHospitalId"
    type="number"
    value="1"
>


<button onclick="nextPatient()">

    Take Next Patient

</button>


<div id="doctorStatus">

</div>


<div id="consultationControls">

</div>

</section>



<!-- =====================================================
     QUEUE
====================================================== -->

<section class="card full">

<div class="queueHeader">

    <div>

        <h2>Live Virtual Queue</h2>

        <p>
            Automatically updated from MySQL
        </p>

    </div>


    <button onclick="loadQueue()">

        Refresh

    </button>

</div>


<div id="queue">

    Loading queue...

</div>

</section>



</main>
<script>




let currentTriageId = null;

let currentConsultationQueueId = null;


/*
|--------------------------------------------------------------------------
| API helper
|--------------------------------------------------------------------------
*/

async function api(route, method = "GET", data = null)
{
    const url = "api.php?route=" + route;

    const options = {
        method,
        headers: {
            "Accept": "application/json"
        }
    };

    if (data !== null) {
        options.headers["Content-Type"] = "application/json";
        options.body = JSON.stringify(data);
    }

    const response = await fetch(url, options);
    const raw = await response.text();

    let result;

    try {
        result = raw ? JSON.parse(raw) : {};
    } catch (parseError) {
        console.error("API returned non-JSON data:", raw);
        throw new Error(
            "The server returned an invalid response. Check PHP/MySQL for an error."
        );
    }

    if (!response.ok) {
        throw new Error(
            result.error || "Request failed (HTTP " + response.status + ")"
        );
    }

    return result;
}

/*
|--------------------------------------------------------------------------
| Load queue
|--------------------------------------------------------------------------
*/

async function loadQueue()
{
    const hospitalId = document
        .getElementById("doctorHospitalId")
        .value
        .trim();

    if (!hospitalId) {
        return;
    }

    try {
        const result = await api(
            "queue&hospital_id=" + encodeURIComponent(hospitalId)
        );

        displayQueue(result.queue || []);
    }
    catch (error) {
        document.getElementById("queue").innerHTML =
            `<div class="error">${escapeHtml(error.message)}</div>`;
    }
}

function escapeHtml(value)
{
    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

/*
|--------------------------------------------------------------------------
| Display queue
|--------------------------------------------------------------------------
*/

function displayQueue(queue)
{

    const container =
        document
        .getElementById(
            "queue"
        );


    if (!queue.length) {

        container.innerHTML =
            `<div class="empty">
                No patients in queue.
            </div>`;

        return;
    }


    container.innerHTML =
        queue.map(
            patient => {

                const urgency =
                    patient.effective_urgency
                    .toLowerCase();


                return `

                <div class="queueItem">

                    <div class="queueNumber">

                        #${escapeHtml(patient.queue_number)}

                    </div>


                    <div class="patientInfo">

                        <strong>
                            ${escapeHtml(patient.full_name)}
                        </strong>

                        <span>
                            Position:
                            ${escapeHtml(patient.position ?? "-")}
                        </span>

                        <span>
                            Waiting:
                            ${escapeHtml(patient.waiting_minutes)}
                            min
                        </span>

                    </div>


                    <div>

                        <span class="
                            urgency
                            ${urgency}
                        ">

                            ${
                                patient.effective_urgency
                            }

                        </span>

                    </div>


                    <div>

                        <span>
                            Priority:
                        </span>

                        <strong>

                            ${
                                patient.priority_score
                            }

                        </strong>

                    </div>


                    <div>

                        <span class="
                            status
                        ">

                            ${escapeHtml(patient.status)}

                        </span>

                    </div>

                </div>

                `;
            }
        )
        .join("");
}


/*
|--------------------------------------------------------------------------
| Doctor takes next patient
|--------------------------------------------------------------------------
*/

async function nextPatient()
{

    const doctorId =
        document
        .getElementById(
            "doctorId"
        )
        .value;


    const hospitalId =
        document
        .getElementById(
            "doctorHospitalId"
        )
        .value;


    if (!doctorId) {

        alert(
            "Enter Doctor ID."
        );

        return;
    }

    if (!hospitalId) {

        alert(
            "Enter Hospital ID."
        );

        return;
    }


    try {

        const result =
            await api(
                "queue_next",
                "POST",
                {
                    doctor_id:
                        doctorId,

                    hospital_id:
                        hospitalId
                }
            );


        currentConsultationQueueId =
            result.queue_id;


        document
        .getElementById(
            "doctorStatus"
        )
        .innerHTML = `

            <div class="success">

                Patient called.

                <br>

                Queue:

                <strong>
                    ${result.queue_number}
                </strong>

                <br>

                Patient ID:

                <strong>
                    ${result.patient_id}
                </strong>

                <br>

                Status:

                <strong>
                    In Consultation
                </strong>

            </div>

        `;


        document
        .getElementById(
            "consultationControls"
        )
        .innerHTML = `

            <textarea
                id="consultationNotes"
                placeholder="Consultation notes..."
            ></textarea>

            <br>

            <button
                onclick="completeConsultation()"
            >

                Complete

            </button>


            <button
                class="danger"
                onclick="referPatient()"
            >

                Refer

            </button>

        `;


        loadQueue();

    }

    catch (error) {

        alert(
            error.message
        );
    }
}


/*
|--------------------------------------------------------------------------
| Complete consultation
|--------------------------------------------------------------------------
*/

async function completeConsultation()
{

    if (
        !currentConsultationQueueId
    ) {

        return;
    }


    const notes =
        document
        .getElementById(
            "consultationNotes"
        )
        .value;


    try {

        await api(
            "queue_complete",
            "POST",
            {
                queue_id:
                    currentConsultationQueueId,

                notes:
                    notes
            }
        );


        document
        .getElementById(
            "doctorStatus"
        )
        .innerHTML =

            `<div class="success">
                Consultation completed.
            </div>`;


        document
        .getElementById(
            "consultationControls"
        )
        .innerHTML = "";


        currentConsultationQueueId =
            null;


        loadQueue();

    }

    catch (error) {

        alert(
            error.message
        );
    }
}


/*
|--------------------------------------------------------------------------
| Refer patient
|--------------------------------------------------------------------------
*/

async function referPatient()
{

    if (
        !currentConsultationQueueId
    ) {

        return;
    }


    const notes =
        document
        .getElementById(
            "consultationNotes"
        )
        .value;


    try {

        await api(
            "queue_refer",
            "POST",
            {
                queue_id:
                    currentConsultationQueueId,

                notes:
                    notes
            }
        );


        document
        .getElementById(
            "doctorStatus"
        )
        .innerHTML =

            `<div class="success">
                Patient referred.
            </div>`;


        document
        .getElementById(
            "consultationControls"
        )
        .innerHTML = "";


        currentConsultationQueueId =
            null;


        loadQueue();

    }

    catch (error) {

        alert(
            error.message
        );
    }
}




/* Automatic queue updates without SSE/reconnecting state. */
window.addEventListener("DOMContentLoaded", function () {
    loadQueue();
    setInterval(loadQueue, 2000);
});


</script>
</body>
</html>
