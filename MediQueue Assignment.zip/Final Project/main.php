<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MediQueue SA | Welcome</title>

    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            min-height: 100vh;
            font-family: Arial, Helvetica, sans-serif;
            background: linear-gradient(135deg, #eef7ff 0%, #ffffff 55%, #eafaf4 100%);
            color: #17324d;
        }

        .top-bar {
            height: 7px;
            background: linear-gradient(90deg, #087f5b, #168aad, #087f5b);
        }

        .navbar {
            width: 100%;
            padding: 22px 7%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: rgba(255,255,255,0.94);
            border-bottom: 1px solid #e4edf3;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 13px;
        }

        .brand-icon {
            width: 46px;
            height: 46px;
            border-radius: 12px;
            background: #087f5b;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            font-weight: bold;
        }

        .brand h1 {
            font-size: 23px;
        }

        .brand span {
            display: block;
            color: #6b7c8d;
            font-size: 12px;
            margin-top: 3px;
        }

        .status {
            color: #087f5b;
            font-size: 14px;
            font-weight: bold;
        }

        .hero {
            max-width: 1120px;
            margin: 0 auto;
            padding: 75px 25px 30px;
            text-align: center;
        }

        .badge {
            display: inline-block;
            padding: 8px 15px;
            border-radius: 30px;
            background: #dff6ed;
            color: #087f5b;
            font-size: 13px;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .hero h2 {
            font-size: clamp(38px, 6vw, 64px);
            line-height: 1.05;
            margin-bottom: 18px;
            color: #153b56;
        }

        .hero h2 strong {
            color: #087f5b;
        }

        .hero p {
            max-width: 680px;
            margin: auto;
            color: #617487;
            font-size: 18px;
            line-height: 1.7;
        }

        .roles {
            max-width: 1000px;
            margin: 45px auto 0;
            padding: 0 25px;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 25px;
        }

        .role-card {
            background: white;
            border: 1px solid #e1ebf1;
            border-radius: 20px;
            padding: 38px;
            text-align: left;
            box-shadow: 0 14px 40px rgba(30, 70, 95, 0.08);
            transition: transform .2s ease, box-shadow .2s ease;
        }

        .role-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 48px rgba(30, 70, 95, 0.13);
        }

        .role-icon {
            width: 64px;
            height: 64px;
            border-radius: 17px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 31px;
            margin-bottom: 22px;
        }

        .patient-icon {
            background: #e5f4ff;
        }

        .doctor-icon {
            background: #e2f7ef;
        }

        .role-card h3 {
            font-size: 27px;
            margin-bottom: 10px;
            color: #183b55;
        }

        .role-card p {
            color: #6a7c8d;
            line-height: 1.6;
            min-height: 52px;
            margin-bottom: 28px;
        }

        .role-button {
            width: 100%;
            border: none;
            border-radius: 11px;
            padding: 15px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            color: white;
            transition: opacity .2s ease, transform .2s ease;
        }

        .role-button:hover {
            opacity: .9;
            transform: translateY(-1px);
        }

        .patient-button {
            background: #168aad;
        }

        .doctor-button {
            background: #087f5b;
        }

        .features {
            max-width: 1000px;
            margin: 35px auto 70px;
            padding: 0 25px;
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
        }

        .feature {
            background: rgba(255,255,255,.75);
            border: 1px solid #e3edf2;
            border-radius: 13px;
            padding: 18px;
            text-align: center;
        }

        .feature b {
            display: block;
            margin-bottom: 5px;
            color: #183b55;
        }

        .feature span {
            color: #738493;
            font-size: 13px;
        }

        footer {
            text-align: center;
            padding: 22px;
            color: #8493a0;
            font-size: 12px;
            border-top: 1px solid #e6edf1;
            background: white;
        }

        @media (max-width: 700px) {
            .navbar {
                padding: 18px 5%;
            }

            .status {
                display: none;
            }

            .hero {
                padding-top: 50px;
            }

            .roles,
            .features {
                grid-template-columns: 1fr;
            }

            .role-card {
                padding: 28px;
            }
        }
    </style>
</head>

<body>

<div class="top-bar"></div>

<nav class="navbar">
    <div class="brand">
        <div class="brand-icon">+</div>
        <div>
            <h1>MediQueue SA</h1>
            <span>Virtual Healthcare Queue</span>
        </div>
    </div>

    <div class="status">● SYSTEM ONLINE</div>
</nav>

<section class="hero">
    <div class="badge">WELCOME TO MEDIQUEUE</div>

    <h2>
        Healthcare made<br>
        <strong>simpler.</strong>
    </h2>

    <p>
        A virtual healthcare queue that connects patients
        with doctors while making the waiting process
        faster, clearer and more organised.
    </p>
</section>

<section class="roles">

    <div class="role-card">
        <div class="role-icon patient-icon">👤</div>

        <h3>I'm a Patient</h3>

        <p>
            Submit your symptoms, join the virtual queue
            and keep track of your waiting status in real time.
        </p>

        <button class="role-button patient-button"
                onclick="window.location.href='patient.php'">
            Continue as Patient →
        </button>
    </div>

    <div class="role-card">
        <div class="role-icon doctor-icon">👨‍⚕️</div>

        <h3>I'm a Doctor</h3>

        <p>
            View patients waiting in the queue, start
            consultations and complete or refer patients.
        </p>

        <button class="role-button doctor-button"
                onclick="window.location.href='doctor.php'">
            Continue as Doctor →
        </button>
    </div>

</section>

<section class="features">

    <div class="feature">
        <b>⚡ Live Queue</b>
        <span>Queue information updates automatically.</span>
    </div>

    <div class="feature">
        <b>🔒 Secure Access</b>
        <span>Separate patient and doctor interfaces.</span>
    </div>

    <div class="feature">
        <b>🏥 Virtual Care</b>
        <span>Organised healthcare without unnecessary waiting.</span>
    </div>

</section>

<footer>
    MediQueue SA &nbsp;•&nbsp; Virtual Healthcare Queue
</footer>

</body>
</html>
