<?php

/*
|--------------------------------------------------------------------------
| MediQueue SA API
|
|
| API + Queueing + Live Updates
|--------------------------------------------------------------------------
*/


ini_set("display_errors", "0");
error_reporting(E_ALL);

require_once __DIR__ . "/db.php";

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    exit;
}


/*
|--------------------------------------------------------------------------
| Response helper
|--------------------------------------------------------------------------
*/

function jsonResponse($data, $status = 200)
{
    http_response_code($status);

    header("Content-Type: application/json");

    echo json_encode(
        $data,
        JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE
    );

    exit;
}


/*
|--------------------------------------------------------------------------
| Read JSON
|--------------------------------------------------------------------------
*/

set_exception_handler(function (Throwable $e) {
    http_response_code(500);
    header("Content-Type: application/json; charset=utf-8");
    echo json_encode([
        "success" => false,
        "error" => "Server error: " . $e->getMessage()
    ]);
    exit;
});

set_error_handler(function ($severity, $message, $file, $line) {
    if (!(error_reporting() & $severity)) {
        return false;
    }
    throw new ErrorException($message, 0, $severity, $file, $line);
});

function getInput()
{
    $body = file_get_contents("php://input");

    if (!$body) {
        return [];
    }

    $data = json_decode(
        $body,
        true
    );

    return is_array($data)
        ? $data
        : [];
}


/*
|--------------------------------------------------------------------------
| GET /api/health
|--------------------------------------------------------------------------
*/

if (
    $_SERVER["REQUEST_METHOD"] === "GET"
    &&
    ($_GET["route"] ?? "") === "health"
) {

    jsonResponse([
        "success" => true,
        "service" => "MediQueue SA API",
        "owner" => "Ethan Naidoo",
        "database" => "mediqueue_sa",
        "live_updates" => "Server-Sent Events"
    ]);
}


/*
|--------------------------------------------------------------------------
| POST /api/triage
|--------------------------------------------------------------------------
|
| Saves triage directly into triage_records.
|
|--------------------------------------------------------------------------
*/

if (
    $_SERVER["REQUEST_METHOD"] === "POST"
    &&
    ($_GET["route"] ?? "") === "triage"
) {

    $data = getInput();

    $patientId =
        (int)($data["patient_id"] ?? 0);

    $symptoms =
        trim(
            $data["symptoms"] ?? ""
        );

    if ($patientId <= 0) {

        jsonResponse([
            "error" =>
                "patient_id is required"
        ], 422);
    }

    if ($symptoms === "") {

        jsonResponse([
            "error" =>
                "At least one symptom is required"
        ], 422);
    }


    /*
    |--------------------------------------------------------------------------
    | Rule-based triage
    |--------------------------------------------------------------------------
    |
    | This is deliberately rule-based for the student MVP.
    |
    */

    $text =
        strtolower($symptoms);

    $highSymptoms = [

        "chest pain",
        "severe breathing difficulty",
        "difficulty breathing",
        "unconscious",
        "severe bleeding",
        "heavy bleeding",
        "stroke",
        "seizure"
    ];

    $moderateSymptoms = [

        "shortness of breath",
        "high fever",
        "persistent vomiting",
        "severe pain",
        "infection",
        "dizziness",
        "dehydration"
    ];

    $urgency = "Low";


    foreach (
        $highSymptoms
        as $symptom
    ) {

        if (
            strpos(
                $text,
                $symptom
            ) !== false
        ) {

            $urgency = "High";

            break;
        }
    }


    if ($urgency === "Low") {

        foreach (
            $moderateSymptoms
            as $symptom
        ) {

            if (
                strpos(
                    $text,
                    $symptom
                ) !== false
            ) {

                $urgency = "Moderate";

                break;
            }
        }
    }


    /*
    |--------------------------------------------------------------------------
    | Verify patient exists before inserting the child record.
    | This prevents a raw MySQL foreign-key error when an invalid/demo ID is used.
    |--------------------------------------------------------------------------
    */

    $patientStmt = $pdo->prepare(
        "SELECT id FROM patients WHERE id = ? LIMIT 1"
    );
    $patientStmt->execute([$patientId]);

    if (!$patientStmt->fetch()) {
        /*
         * Patients are created automatically as Patient 1, Patient 2,
         * Patient 3, ... so the system is not limited to preloaded records.
         */
        try {
            $pdo->beginTransaction();

            $email = "patient" . $patientId . "@mediqueue.local";

            $userStmt = $pdo->prepare(
                "INSERT INTO users (email, password_hash, role)
                 VALUES (?, '', 'patient')"
            );
            $userStmt->execute([$email]);

            $userId = (int)$pdo->lastInsertId();

            $createPatient = $pdo->prepare(
                "INSERT INTO patients
                    (id, user_id, full_name)
                 VALUES
                    (?, ?, ?)"
            );
            $createPatient->execute([
                $patientId,
                $userId,
                "Patient " . $patientId
            ]);

            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            /*
             * Another request may have created this patient at the same time.
             * Re-check before returning an error.
             */
            $patientStmt->execute([$patientId]);

            if (!$patientStmt->fetch()) {
                throw $e;
            }
        }
    }


    /*
    |--------------------------------------------------------------------------
    | Save triage record
    |--------------------------------------------------------------------------
    */

    $stmt =
        $pdo->prepare(
            "INSERT INTO triage_records
            (
                patient_id,
                symptoms,
                urgency
            )
            VALUES
            (
                ?,
                ?,
                ?
            )"
        );

    $stmt->execute([
        $patientId,
        $symptoms,
        $urgency
    ]);

    $triageId =
        (int)$pdo->lastInsertId();


    jsonResponse([
        "success" => true,
        "triage_id" => $triageId,
        "patient_id" => $patientId,
        "symptoms" => $symptoms,
        "urgency" => $urgency
    ], 201);
}


/*
|--------------------------------------------------------------------------
| POST /api/queue/join
|--------------------------------------------------------------------------
*/

if (
    $_SERVER["REQUEST_METHOD"] === "POST"
    &&
    ($_GET["route"] ?? "") === "queue_join"
) {

    $data = getInput();

    $patientId =
        (int)($data["patient_id"] ?? 0);

    $triageId =
        (int)($data["triage_id"] ?? 0);

    $hospitalId =
        (int)($data["hospital_id"] ?? 0);


    if ($patientId <= 0) {

        jsonResponse([
            "error" =>
                "patient_id is required"
        ], 422);
    }

    if ($triageId <= 0) {

        jsonResponse([
            "error" =>
                "triage_id is required"
        ], 422);
    }

    if ($hospitalId <= 0) {

        jsonResponse([
            "error" =>
                "hospital_id is required"
        ], 422);
    }


    /*
    |--------------------------------------------------------------------------
    | Check hospital exists
    |--------------------------------------------------------------------------
    */

    $hospitalStmt = $pdo->prepare(
        "SELECT id FROM hospitals WHERE id = ? LIMIT 1"
    );
    $hospitalStmt->execute([$hospitalId]);

    if (!$hospitalStmt->fetch()) {
        jsonResponse([
            "error" => "Hospital ID {$hospitalId} does not exist. Run schema.sql to load the demo hospital, or enter an existing hospital ID."
        ], 404);
    }


    /*
    |--------------------------------------------------------------------------
    | Check patient exists
    |--------------------------------------------------------------------------
    */

    $stmt =
        $pdo->prepare(
            "SELECT
                id,
                full_name
             FROM patients
             WHERE id = ?"
        );

    $stmt->execute([
        $patientId
    ]);

    $patient =
        $stmt->fetch();


    if (!$patient) {

        jsonResponse([
            "error" =>
                "Patient not found"
        ], 404);
    }


    /*
    |--------------------------------------------------------------------------
    | Get triage
    |--------------------------------------------------------------------------
    */

    $stmt =
        $pdo->prepare(
            "SELECT
                id,
                urgency
             FROM triage_records
             WHERE id = ?
             AND patient_id = ?"
        );

    $stmt->execute([
        $triageId,
        $patientId
    ]);

    $triage =
        $stmt->fetch();


    if (!$triage) {

        jsonResponse([
            "error" =>
                "Triage record not found"
        ], 404);
    }


    /*
    |--------------------------------------------------------------------------
    | Prevent duplicate active queue entries
    |--------------------------------------------------------------------------
    */

    $stmt =
        $pdo->prepare(
            "SELECT id, queue_number, status
             FROM queue_entries
             WHERE patient_id = ?
             AND hospital_id = ?
             AND status IN
             (
                'Waiting',
                'In Consultation'
             )
             LIMIT 1"
        );

    $stmt->execute([
        $patientId,
        $hospitalId
    ]);

    $existing =
        $stmt->fetch();


    if ($existing) {

        jsonResponse([
            "error" =>
                "Patient already has an active queue entry",

            "queue_id" =>
                $existing["id"],

            "queue_number" =>
                $existing["queue_number"],

            "status" =>
                $existing["status"]
        ], 409);
    }


    /*
    |--------------------------------------------------------------------------
    | Generate queue number
    |--------------------------------------------------------------------------
    */

    $stmt =
        $pdo->prepare(
            "SELECT
                COUNT(*) + 1 AS next_number
             FROM queue_entries
             WHERE hospital_id = ?
             AND DATE(joined_at) = CURDATE()"
        );

    $stmt->execute([
        $hospitalId
    ]);

    $next =
        (int)$stmt->fetch()["next_number"];


    $queueNumber =
        "MQ-" .
        date("Ymd") .
        "-" .
        str_pad(
            $next,
            3,
            "0",
            STR_PAD_LEFT
        );


    /*
    |--------------------------------------------------------------------------
    | Insert queue entry
    |--------------------------------------------------------------------------
    */

    $stmt =
        $pdo->prepare(
            "INSERT INTO queue_entries
            (
                queue_number,
                hospital_id,
                patient_id,
                triage_id,
                urgency,
                status
            )
            VALUES
            (
                ?,
                ?,
                ?,
                ?,
                ?,
                'Waiting'
            )"
        );

    $stmt->execute([
        $queueNumber,
        $hospitalId,
        $patientId,
        $triageId,
        $triage["urgency"]
    ]);


    $queueId =
        (int)$pdo->lastInsertId();


    jsonResponse([
        "success" => true,
        "queue_id" => $queueId,
        "queue_number" => $queueNumber,
        "patient_id" => $patientId,
        "status" => "Waiting",
        "urgency" => $triage["urgency"]
    ], 201);
}


/*
|--------------------------------------------------------------------------
| GET /api/queue
|--------------------------------------------------------------------------
|
| Correct priority queue.
|
| 75% urgency
| 25% waiting time
|
|--------------------------------------------------------------------------
*/

if (
    $_SERVER["REQUEST_METHOD"] === "GET"
    &&
    ($_GET["route"] ?? "") === "queue"
) {

    $hospitalId =
        (int)($_GET["hospital_id"] ?? 0);


    if ($hospitalId <= 0) {

        jsonResponse([
            "error" =>
                "hospital_id is required"
        ], 422);
    }


    /*
    |--------------------------------------------------------------------------
    | Priority calculation
    |--------------------------------------------------------------------------
    |
    | High    = 75
    | Moderate = 50
    | Low      = 25
    |
    | Waiting time adds up to 25 points.
    |
    | After 60 minutes:
    | Low -> Moderate
    |
    | After 90 minutes:
    | Any waiting patient -> High
    |
    |--------------------------------------------------------------------------
    */

    $sql = "
        SELECT

            q.id,
            q.queue_number,
            q.patient_id,
            p.full_name,
            q.urgency,
            q.status,
            q.joined_at,
            q.started_at,
            q.completed_at,

            TIMESTAMPDIFF(
                MINUTE,
                q.joined_at,
                NOW()
            ) AS waiting_minutes,

            CASE

                WHEN
                    TIMESTAMPDIFF(
                        MINUTE,
                        q.joined_at,
                        NOW()
                    ) >= 90
                THEN 'High'

                WHEN
                    q.urgency = 'Low'
                    AND
                    TIMESTAMPDIFF(
                        MINUTE,
                        q.joined_at,
                        NOW()
                    ) >= 60
                THEN 'Moderate'

                ELSE q.urgency

            END AS effective_urgency,

            CASE

                WHEN
                    (
                        CASE
                            WHEN q.urgency = 'High'
                                THEN 75
                            WHEN q.urgency = 'Moderate'
                                THEN 50
                            ELSE 25
                        END
                    )
                    +
                    LEAST(
                        25,
                        (
                            TIMESTAMPDIFF(
                                MINUTE,
                                q.joined_at,
                                NOW()
                            ) / 90
                        ) * 25
                    )
                    > 100
                THEN 100

                ELSE

                    (
                        CASE
                            WHEN q.urgency = 'High'
                                THEN 75
                            WHEN q.urgency = 'Moderate'
                                THEN 50
                            ELSE 25
                        END
                    )
                    +
                    LEAST(
                        25,
                        (
                            TIMESTAMPDIFF(
                                MINUTE,
                                q.joined_at,
                                NOW()
                            ) / 90
                        ) * 25
                    )

            END AS priority_score

        FROM queue_entries q

        INNER JOIN patients p
            ON p.id = q.patient_id

        WHERE
            q.hospital_id = ?
            AND q.status IN ('Waiting', 'In Consultation')

        ORDER BY

            CASE
                WHEN q.status = 'Waiting'
                    THEN 1
                WHEN q.status = 'In Consultation'
                    THEN 2
                ELSE 3
            END,

            priority_score DESC,

            q.joined_at ASC
    ";


    $stmt =
        $pdo->prepare($sql);

    $stmt->execute([
        $hospitalId
    ]);

    $queue =
        $stmt->fetchAll();


    /*
    |--------------------------------------------------------------------------
    | Add position
    |--------------------------------------------------------------------------
    */

    $position = 1;

    foreach (
        $queue
        as &$patient
    ) {

        if (
            $patient["status"]
            ===
            "Waiting"
        ) {

            $patient["position"] =
                $position++;

        } else {

            $patient["position"] =
                null;
        }


        $patient["priority_score"] =
            round(
                (float)$patient["priority_score"],
                2
            );
    }


    jsonResponse([
        "success" => true,
        "queue" => $queue
    ]);
}


/*
|--------------------------------------------------------------------------
| POST /api/queue/next
|--------------------------------------------------------------------------
|
| Doctor takes the correct next patient.
|
| Uses a transaction + FOR UPDATE so two doctors
| cannot take the same patient simultaneously.
|
|--------------------------------------------------------------------------
*/

if (
    $_SERVER["REQUEST_METHOD"] === "POST"
    &&
    ($_GET["route"] ?? "") === "queue_next"
) {

    $data = getInput();

    $doctorId =
        (int)($data["doctor_id"] ?? 0);

    $hospitalId =
        (int)($data["hospital_id"] ?? 0);


    if ($doctorId <= 0) {

        jsonResponse([
            "error" =>
                "doctor_id is required"
        ], 422);
    }

    if ($hospitalId <= 0) {

        jsonResponse([
            "error" =>
                "hospital_id is required"
        ], 422);
    }

    /* Verify that the doctor exists and belongs to the selected hospital. */
    $doctorStmt = $pdo->prepare(
        "SELECT id, hospital_id, available, full_name
         FROM doctors
         WHERE id = ?
         LIMIT 1"
    );
    $doctorStmt->execute([$doctorId]);
    $doctor = $doctorStmt->fetch();

    if (!$doctor) {
        jsonResponse([
            "error" => "Doctor not found"
        ], 404);
    }

    if ((int)$doctor["hospital_id"] !== $hospitalId) {
        jsonResponse([
            "error" => "Doctor does not belong to this hospital"
        ], 409);
    }

    if (!(bool)$doctor["available"]) {
        jsonResponse([
            "error" => "Doctor is currently unavailable"
        ], 409);
    }


    try {

        $pdo->beginTransaction();


        /*
        |--------------------------------------------------------------------------
        | Lock the highest priority waiting patient
        |--------------------------------------------------------------------------
        */

        $sql = "

            SELECT

                q.id,
                q.queue_number,
                q.patient_id,
                q.triage_id,
                q.urgency,
                q.status,
                q.joined_at

            FROM queue_entries q

            WHERE

                q.hospital_id = ?

                AND

                q.status = 'Waiting'

            ORDER BY

                CASE

                    WHEN
                        TIMESTAMPDIFF(
                            MINUTE,
                            q.joined_at,
                            NOW()
                        ) >= 90
                    THEN 3

                    WHEN
                        q.urgency = 'High'
                    THEN 3

                    WHEN
                        q.urgency = 'Moderate'
                    THEN 2

                    ELSE 1

                END DESC,

                CASE

                    WHEN
                        q.urgency = 'High'
                    THEN 75

                    WHEN
                        q.urgency = 'Moderate'
                    THEN 50

                    ELSE 25

                END

                +

                LEAST(
                    25,
                    (
                        TIMESTAMPDIFF(
                            MINUTE,
                            q.joined_at,
                            NOW()
                        ) / 90
                    ) * 25
                ) DESC,

                q.joined_at ASC

            LIMIT 1

            FOR UPDATE

        ";


        $stmt =
            $pdo->prepare($sql);

        $stmt->execute([
            $hospitalId
        ]);

        $patient =
            $stmt->fetch();


        if (!$patient) {

            $pdo->rollBack();

            jsonResponse([
                "error" =>
                    "No patients are currently waiting"
            ], 404);
        }


        /*
        |--------------------------------------------------------------------------
        | Update queue
        |--------------------------------------------------------------------------
        */

        $stmt =
            $pdo->prepare(
                "UPDATE queue_entries

                 SET
                    doctor_id = ?,
                    status = 'In Consultation',
                    started_at = NOW()

                 WHERE id = ?

                 AND status = 'Waiting'"
            );

        $stmt->execute([
            $doctorId,
            $patient["id"]
        ]);


        /*
        |--------------------------------------------------------------------------
        | Check that update actually happened
        |--------------------------------------------------------------------------
        */

        if (
            $stmt->rowCount() !== 1
        ) {

            $pdo->rollBack();

            jsonResponse([
                "error" =>
                    "Patient was already taken"
            ], 409);
        }


        /*
        |--------------------------------------------------------------------------
        | Create consultation record
        |--------------------------------------------------------------------------
        |
        | Notes can be filled in later by the doctor.
        |
        */

        $stmt =
            $pdo->prepare(
                "INSERT INTO consultations
                (
                    queue_entry_id,
                    patient_id,
                    doctor_id,
                    notes,
                    outcome
                )
                VALUES
                (
                    ?,
                    ?,
                    ?,
                    '',
                    'In Progress'
                )"
            );

        $stmt->execute([
            $patient["id"],
            $patient["patient_id"],
            $doctorId
        ]);


        $consultationId =
            (int)$pdo->lastInsertId();


        $pdo->commit();


        jsonResponse([
            "success" => true,

            "queue_id" =>
                $patient["id"],

            "queue_number" =>
                $patient["queue_number"],

            "patient_id" =>
                $patient["patient_id"],

            "doctor_id" =>
                $doctorId,

            "consultation_id" =>
                $consultationId,

            "status" =>
                "In Consultation"
        ]);
    }

    catch (Throwable $e) {

        if (
            $pdo->inTransaction()
        ) {

            $pdo->rollBack();
        }

        jsonResponse([
            "error" =>
                $e->getMessage()
        ], 500);
    }
}


/*
|--------------------------------------------------------------------------
| POST /api/queue/complete
|--------------------------------------------------------------------------
*/

if (
    $_SERVER["REQUEST_METHOD"] === "POST"
    &&
    ($_GET["route"] ?? "") === "queue_complete"
) {

    $data = getInput();

    $queueId =
        (int)($data["queue_id"] ?? 0);

    $notes =
        trim(
            $data["notes"] ?? ""
        );


    if ($queueId <= 0) {

        jsonResponse([
            "error" =>
                "queue_id is required"
        ], 422);
    }


    $pdo->beginTransaction();


    try {

        /*
        |--------------------------------------------------------------------------
        | Lock queue entry
        |--------------------------------------------------------------------------
        */

        $stmt =
            $pdo->prepare(
                "SELECT *
                 FROM queue_entries
                 WHERE id = ?
                 FOR UPDATE"
            );

        $stmt->execute([
            $queueId
        ]);

        $queue =
            $stmt->fetch();


        if (!$queue) {

            throw new Exception(
                "Queue entry not found"
            );
        }


        if (
            $queue["status"]
            !==
            "In Consultation"
        ) {

            throw new Exception(
                "Patient is not currently in consultation"
            );
        }


        /*
        |--------------------------------------------------------------------------
        | Update queue
        |--------------------------------------------------------------------------
        */

        $stmt =
            $pdo->prepare(
                "UPDATE queue_entries

                 SET
                    status = 'Completed',
                    completed_at = NOW()

                 WHERE id = ?"
            );

        $stmt->execute([
            $queueId
        ]);


        /*
        |--------------------------------------------------------------------------
        | Update consultation
        |--------------------------------------------------------------------------
        */

        $stmt =
            $pdo->prepare(
                "UPDATE consultations

                 SET
                    notes = ?,
                    outcome = 'Completed'

                 WHERE queue_entry_id = ?"
            );

        $stmt->execute([
            $notes,
            $queueId
        ]);


        $pdo->commit();


        jsonResponse([
            "success" => true,
            "queue_id" => $queueId,
            "status" => "Completed"
        ]);
    }

    catch (Throwable $e) {

        $pdo->rollBack();

        jsonResponse([
            "error" =>
                $e->getMessage()
        ], 409);
    }
}


/*
|--------------------------------------------------------------------------
| POST /api/queue/refer
|--------------------------------------------------------------------------
*/

if (
    $_SERVER["REQUEST_METHOD"] === "POST"
    &&
    ($_GET["route"] ?? "") === "queue_refer"
) {

    $data = getInput();

    $queueId =
        (int)($data["queue_id"] ?? 0);

    $notes =
        trim(
            $data["notes"] ?? ""
        );


    if ($queueId <= 0) {

        jsonResponse([
            "error" =>
                "queue_id is required"
        ], 422);
    }


    $pdo->beginTransaction();


    try {

        $stmt =
            $pdo->prepare(
                "SELECT *
                 FROM queue_entries
                 WHERE id = ?
                 FOR UPDATE"
            );

        $stmt->execute([
            $queueId
        ]);

        $queue =
            $stmt->fetch();


        if (!$queue) {

            throw new Exception(
                "Queue entry not found"
            );
        }


        if (
            $queue["status"]
            !==
            "In Consultation"
        ) {

            throw new Exception(
                "Patient is not currently in consultation"
            );
        }


        /*
        |--------------------------------------------------------------------------
        | Update queue
        |--------------------------------------------------------------------------
        */

        $stmt =
            $pdo->prepare(
                "UPDATE queue_entries

                 SET
                    status = 'Referral',
                    completed_at = NOW()

                 WHERE id = ?"
            );

        $stmt->execute([
            $queueId
        ]);


        /*
        |--------------------------------------------------------------------------
        | Update consultation
        |--------------------------------------------------------------------------
        */

        $stmt =
            $pdo->prepare(
                "UPDATE consultations

                 SET
                    notes = ?,
                    outcome = 'Referral'

                 WHERE queue_entry_id = ?"
            );

        $stmt->execute([
            $notes,
            $queueId
        ]);


        $pdo->commit();


        jsonResponse([
            "success" => true,
            "queue_id" => $queueId,
            "status" => "Referral"
        ]);
    }

    catch (Throwable $e) {

        $pdo->rollBack();

        jsonResponse([
            "error" =>
                $e->getMessage()
        ], 409);
    }
}


/*
|--------------------------------------------------------------------------
| GET /api/events
|--------------------------------------------------------------------------
|
| Live Server-Sent Events.
|
| The browser stays connected and the server checks the
| database for queue changes.
|
|--------------------------------------------------------------------------
*/

if (
    $_SERVER["REQUEST_METHOD"] === "GET"
    &&
    ($_GET["route"] ?? "") === "events"
) {

    $hospitalId =
        (int)($_GET["hospital_id"] ?? 0);


    if ($hospitalId <= 0) {

        http_response_code(422);

        echo "hospital_id is required";

        exit;
    }


    header(
        "Content-Type: text/event-stream"
    );

    header(
        "Cache-Control: no-cache"
    );

    header(
        "Connection: keep-alive"
    );

    header(
        "X-Accel-Buffering: no"
    );


    /*
    |--------------------------------------------------------------------------
    | Get current queue update timestamp
    |--------------------------------------------------------------------------
    */

    $lastSignature = "";


    $startTime =
        time();


    /*
    |--------------------------------------------------------------------------
    | Keep connection open for 30 seconds.
    |
    | Browser automatically reconnects.
    |--------------------------------------------------------------------------
    */

    while (
        time() - $startTime < 30
    ) {

        $stmt =
            $pdo->prepare(
                "SELECT

                    COUNT(*) AS total,

                    COALESCE(
                        MAX(
                            updated_at
                        ),
                        '1970-01-01 00:00:00'
                    ) AS latest_update

                 FROM queue_entries

                 WHERE hospital_id = ?"
            );

        $stmt->execute([
            $hospitalId
        ]);

        $state =
            $stmt->fetch();


        $signature =
            $state["total"]
            .
            "|"
            .
            $state["latest_update"];


        /*
        |--------------------------------------------------------------------------
        | Send event when database changed
        |--------------------------------------------------------------------------
        */

        if (
            $signature !==
            $lastSignature
        ) {

            echo "event: queue.updated\n";

            echo
                "data: "
                .
                json_encode([
                    "hospital_id" =>
                        $hospitalId,

                    "total" =>
                        (int)$state["total"],

                    "updated_at" =>
                        $state["latest_update"]
                ])
                .
                "\n\n";


            $lastSignature =
                $signature;


            @ob_flush();

            @flush();
        }


        /*
        |--------------------------------------------------------------------------
        | Heartbeat
        |--------------------------------------------------------------------------
        */

        echo ": heartbeat\n\n";

        @ob_flush();

        @flush();


        sleep(1);
    }


    exit;
}


/*
|--------------------------------------------------------------------------
| Unknown route
|--------------------------------------------------------------------------
*/

jsonResponse([
    "error" =>
        "Route not found"
], 404);
?>